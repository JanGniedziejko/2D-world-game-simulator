#include "Animal.h"
#include "Hogweed.h"
#include "Guarana.h"
#include "Human.h"

using namespace std;

Animal::Animal(World *world, int strength, int initiative, int x, int y, int age, bool newBorn)
: Organism(world, strength, initiative, x, y, age, newBorn){
};

// checking if colliding organisms are the same 
bool Animal::Same_Species(Organism &organism){
    return (this->getName() == organism.getName());
};

void Animal::breed(){
    if (this->getName().compare("Human")) {
        int* newPosition = FindUnoccupiedField();
        if (newPosition[0] == -1 && newPosition[1] == -1) {
            cout << "No empty fields around\n";
            return;
        }
        reproduction(newPosition[0], newPosition[1]); // if there is a free field nearby, then placing new organism there
        delete newPosition;
    }
};

bool Animal::is_animal() {
    return true;
};

void Animal::action(){
    if(this->getName().compare("Turtle")){
        age++;
    }
    int *newPosition = pathFindNewField();
    // default option for making a move
    if(world->Organism_board[newPosition[0]][newPosition[1]] == nullptr){
        world->Organism_board[newPosition[0]][newPosition[1]] = this;
        world->Organism_board[position[0]][position[1]] = nullptr;
        position[0] = newPosition[0];
        position[1] = newPosition[1];
    }
    else{
        // collision with different organism
        collision(world->Organism_board[newPosition[0]][newPosition[1]]);
    }
    delete newPosition;
};

void Animal::collision(Organism *colliding_organism){
    // if there are the same species, then breed
    if(this->getName().compare("Human") && Same_Species(*colliding_organism)) {
            cout << "Breeding of " << this->getName() << " at (" << position[0] << "," << position[1] << ") \n";
            breed();
            return;
    }
    else{
        // if one of the colliding organisms is turtle
        if(colliding_organism->reflected(this)){
            cout << "Turtle reflected " << this->getName() << "'s attack at (" << position[0] << "," << position[1] << ")\n"<<endl;
            return;
        }

        if (colliding_organism->is_animal()) {
            cout << "Fight between: " << this->getName() << " and " << colliding_organism->getName() << " at (" << position[0] << "," << position[1] << ") ---> ";
        }
        // if CyberSheep collids with Hogweed
        if (!this->getName().compare("CyberSheep") && !colliding_organism->getName().compare("Hogweed")) {
            world->Organism_board[position[0]][position[1]] = nullptr;
            position[0] = colliding_organism->getX();
            position[1] = colliding_organism->getY();
            world->Organism_board[position[0]][position[1]] = this;

            world->All_organisms->remove(colliding_organism);
        }
        else if(strength >= colliding_organism->getStrength() && colliding_organism->getName().compare("Hogweed")) {
            cout << this->getName() << " won\n";
            // If the colliding organism is Guarana
            if(!colliding_organism->getName().compare("Guarana")) {
                cout << this->getName() << " (" << position[0] << "," << position[1] << ") strength +3.\n";
                strength += 3;
            }
            // Deleting organism from 2d pointer array and from OrganismNode
            world->Organism_board[position[0]][position[1]] = nullptr;
            position[0] = colliding_organism->getX();
            position[1] = colliding_organism->getY();
            world->Organism_board[position[0]][position[1]] = this;

            world->All_organisms->remove(colliding_organism);
        }
        else{
            cout << this->getName() <<" lost\n";
            world->Organism_board[position[0]][position[1]] = nullptr;
            world->All_organisms->remove(this);
        }
    }
};

Animal::~Animal(){
};