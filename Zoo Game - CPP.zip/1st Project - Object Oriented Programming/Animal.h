#ifndef Animal_h
#define Animal_h

#include <iostream>
#include <string>
#include "Organism.h"
using namespace std;

class Animal : public Organism {
    public:
        Animal(World *world, int strength, int initiative, int x, int y, int age, bool newborn);
        bool Same_Species(Organism &organism);
        void breed();
        bool is_animal();
        string getName() override = 0;      
        void draw() override = 0;                 
        void action() override;      
        virtual void collision(Organism *colliding_organism);
        ~Animal();
};

#endif