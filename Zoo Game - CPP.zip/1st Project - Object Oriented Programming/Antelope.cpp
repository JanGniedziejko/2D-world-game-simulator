#include "Antelope.h"
using namespace std;
Antelope::Antelope(World *currentWorld, int x, int y, int age, bool newBorn)
: Animal(currentWorld, 4, 4, x, y, age, newBorn){

};

int *Antelope::pathFindNewField(){
    int *returnPosition = new int[2];

    returnPosition[0] = position[0];
    returnPosition[1] = position[1];

    int field;
    bool invalidMove;
    do {
        // has 8 options to move, because Antelope can move by either one field or two
        field = rand() % 8;
        invalidMove = false;
        switch (field) {
            case 0:
                if(returnPosition[1] == 0)
                    invalidMove = true;
                else returnPosition[1]--;
                break;
            case 1:
                if(returnPosition[0] == world->getWidth() - 1)
                    invalidMove = true;
                else returnPosition[0]++;
                break;
            case 2: 
                if(returnPosition[1] == world->getHeight() - 1)
                    invalidMove = true;
                else returnPosition[1]++;
                break;
            case 3: 
                if(returnPosition[0] == 0)
                    invalidMove = true;
                else returnPosition[0]--;
                break;
            case 4: 
                if(returnPosition[1] <= 1)
                    invalidMove = true;
                else returnPosition[1] -= 2;
                break;
            case 5: 
                if(returnPosition[0] >= world->getWidth() - 2)
                    invalidMove = true;
                else returnPosition[0] += 2;
                break;
            case 6: 
                if(returnPosition[1] >= world->getHeight() - 2)
                    invalidMove = true;
                else returnPosition[1] += 2;
                break;
            case 7:
                if(returnPosition[0] <= 1)
                    invalidMove = true;
                else returnPosition[0] -= 2;
                break;
        }
    }while(invalidMove);

    return returnPosition;
};

void Antelope::draw(){
    printf("A");
};

string Antelope::getName(){
    return ("Antelope");
};

void Antelope::collision(Organism *colliding_organism){
    // Special ability of Antelope (50% chance to escape from fight)
    int escape = rand() % 2;
    if((escape == 0) && !(Same_Species(*colliding_organism)) && (colliding_organism->getStrength() > strength)){
        cout << "Antelope succesfully escaped from " << this->getName() << " at (" << position[0] << "," << position[1] << "), ";
        // Find free neighbouring field for antelope
        int *newPosition = FindUnoccupiedField();
        if((newPosition[0] != -1) && (newPosition[1] != -1)){
            world->Organism_board[newPosition[0]][newPosition[1]] = this;
            world->Organism_board[position[0]][position[1]] = nullptr;
            position[0] = newPosition[0];
            position[1] = newPosition[1];
        }
    }
    else{
        Animal::collision(colliding_organism);
    }
};

Organism *Antelope::reproduction(int x, int y){
    return new Antelope(world, x, y, 1, true);
};

Antelope::~Antelope(){

};