#ifndef Antelope_h
#define Antelope_h

#include <stdio.h>
#include "Animal.h"

class Antelope : public Animal {
    public:
        Antelope(World * world, int x, int y, int age, bool newBorn);
        int *pathFindNewField() override;
        void draw() override;
        string getName() override;
        void collision(Organism * colliding_organism) override;
        Organism * reproduction(int x, int y) override;
        ~Antelope() override;
};

#endif