#include "Belladonna.h"

Belladonna::Belladonna(World *currentWorld, int x, int y, int age, bool newBorn)
: Plant(currentWorld, 99, x, y, age, newBorn){
};

void Belladonna::draw(){
    printf("B");
};

string Belladonna::getName(){
    return ("Belladonna");
};

Organism *Belladonna::reproduction(int x, int y){
    return new Belladonna(world, x, y, 1, true);
};

Belladonna::~Belladonna(){
};