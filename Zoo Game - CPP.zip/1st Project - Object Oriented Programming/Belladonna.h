#ifndef Belladonna_h
#define Belladonna_h

#include <stdio.h>
#include "Plant.h"
#include <string>

class Belladonna : public Plant {
    public:
        Belladonna(World * world, int x, int y, int age, bool newBorn);
        void draw() override;
        string getName() override;
        Organism * reproduction(int x, int y) override;
        ~Belladonna() override;
};

#endif