﻿#include "CyberSheep.h"
#include <math.h>
using namespace std;
CyberSheep::CyberSheep(World* world, int x, int y, int age, bool newBorn)
    : Animal(world, 11, 4, x, y, age, newBorn) {};

void CyberSheep::draw() {
    printf("C");
};

string CyberSheep::getName() {
    return ("CyberSheep");
};
void CyberSheep::action() {
    int newPosition[2];
    int min = 200, temp;
    int chase_X, chase_Y;
    OrganismNode* current = new OrganismNode;
    current = world->All_organisms->head->next;
    while (current != nullptr) {
        if (!current->organism->getName().compare("Hogweed")) {
            temp = sqrt(current->organism->getX() ^ 2 + current->organism->getY() ^ 2);
            if (temp < min) {
                min = temp;
                chase_X = current->organism->getX();
                chase_Y = current->organism->getY();
            }
        }
        current = current->next;
    }
    if (min == 200) {
        int* new_coords = this->pathFindNewField();
        newPosition[0] = new_coords[0];
        newPosition[1] = new_coords[1];
    }
    else if (abs(this->getX() - chase_X) >= abs(this->getY() - chase_Y)) {
        if (this->getX() - chase_X > 0) {
            newPosition[0] = this->getX() - 1;
            newPosition[1] = this->getY();
        }
        else if (this->getX() - chase_X < 0) {
            newPosition[0] = this->getX() + 1;
            newPosition[1] = this->getY();
        }
    }
    else {
        if (this->getY() - chase_Y > 0) {
            newPosition[0] = this->getX();
            newPosition[1] = this->getY() - 1;
        }
        else if (this->getY() - chase_X < 0) {
            newPosition[0] = this->getX();
            newPosition[1] = this->getY() + 1;
        }
    }

    if (world->Organism_board[newPosition[0]][newPosition[1]] == nullptr) {
        world->Organism_board[newPosition[0]][newPosition[1]] = this;
        world->Organism_board[position[0]][position[1]] = nullptr;
        position[0] = newPosition[0];
        position[1] = newPosition[1];
    }
    else {
        collision(world->Organism_board[newPosition[0]][newPosition[1]]);
    }
};

Organism* CyberSheep::reproduction(int x, int y) {
    return new CyberSheep(world, x, y, 1, true);
};

CyberSheep::~CyberSheep() {};

