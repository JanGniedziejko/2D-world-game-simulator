#ifndef CyberSheep_h
#define CyberSheep_h

#include <stdio.h>
#include "Animal.h"

class CyberSheep : public Animal {
public:
    CyberSheep(World* world, int x, int y, int age, bool newBorn);
    void draw() override;
    string getName() override;
    void action() override;
    Organism* reproduction(int x, int y) override;
    ~CyberSheep() override;
};

#endif


