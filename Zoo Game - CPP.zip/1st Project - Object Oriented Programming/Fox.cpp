#include "Fox.h"
using namespace std;
Fox::Fox(World* currentWorld, int x, int y, int age, bool newBorn)
: Animal(currentWorld, 3, 7, x, y, age, newBorn){};

void Fox::draw(){
    printf("F");
};

string Fox::getName(){
    return ("Fox");
};

void Fox::action(){
    age++;
    int *newPosition = pathFindNewField();
    
    if(world->Organism_board[newPosition[0]][newPosition[1]] == nullptr){
        world->Organism_board[newPosition[0]][newPosition[1]] = this;
        world->Organism_board[position[0]][position[1]] = nullptr;
        position[0] = newPosition[0];
        position[1] = newPosition[1];
    }
    else{
        // moves if and only if the fox can win a fight with an organism in the neighbouring field
        if(world->Organism_board[newPosition[0]][newPosition[1]]->getStrength() <= getStrength()){
            collision(world->Organism_board[newPosition[0]][newPosition[1]]);
        }else{
            cout << "Fox is sensing something dangerous at (" << newPosition[0] << "," << newPosition[1] << ")\n";
       }
    }
    delete newPosition;
};

Organism* Fox::reproduction(int x, int y){
    return new Fox(world, x, y, 1, true);
};

Fox::~Fox(){};
