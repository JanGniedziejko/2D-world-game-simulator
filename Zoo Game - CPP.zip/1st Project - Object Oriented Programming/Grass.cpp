#include "Grass.h"

Grass::Grass(World* currentWorld, int x, int y, int age, bool newBorn)
: Plant(currentWorld, 0, x, y, age, newBorn){
};

void Grass::draw(){
    printf("#");
};

string Grass::getName(){
    return ("Grass");
};

Organism *Grass::reproduction(int x, int y){
    return new Grass(world, x, y, 1, true);
};

Grass::~Grass(){
    
};