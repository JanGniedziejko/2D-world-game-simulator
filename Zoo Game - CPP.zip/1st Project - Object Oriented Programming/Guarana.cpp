#include "Guarana.h"

Guarana::Guarana(World *currentWorld, int x, int y, int age, bool newBorn)
: Plant(currentWorld, 0, x, y, age, newBorn){
};

void Guarana::draw(){
    printf("G");
};

string Guarana::getName(){
    return ("Guarana");
};

Organism *Guarana::reproduction(int x, int y){
    return new Guarana(world, x, y, 1, true);
};

Guarana::~Guarana(){

};