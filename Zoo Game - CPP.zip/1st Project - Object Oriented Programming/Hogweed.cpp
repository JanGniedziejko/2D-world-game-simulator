#include "Hogweed.h"
#include "Animal.h"
using namespace std;

Hogweed::Hogweed(World* currentWorld, int x, int y, int age, bool newBorn)
: Plant(currentWorld, 10, x, y, age, newBorn){};

void Hogweed::draw(){
    printf("&");
};

string Hogweed::getName(){
    return ("Hogweed");
};

void Hogweed::action() {
    age++;
    int currentPosition[2];
    currentPosition[0] = position[0];
    currentPosition[1] = position[1];

    int horiz[4] = {0, 1, 0, -1};
    int vertic[4] = { -1, 0, 1, 0 };

    for (int i = 0; i < 4; i++) {
        currentPosition[0] += horiz[i];
        currentPosition[1] += vertic[i];
        if ((currentPosition[0] == 0 || currentPosition[1] == 0) || (currentPosition[0] == world->getWidth() || currentPosition[1] == world->getHeight())) continue;
        else {
            if(world->Organism_board[currentPosition[0]][currentPosition[1]]!= nullptr){
                if (world->Organism_board[currentPosition[0]][currentPosition[1]]->getName().compare("CyberSheep")) {
                    if (world->Organism_board[currentPosition[0]][currentPosition[1]]->is_animal()) {
                        world->All_organisms->remove(world->Organism_board[currentPosition[0]][currentPosition[1] - 1]);
                        world->Organism_board[currentPosition[0]][currentPosition[1]] = nullptr;
                    }
                }

            }
        }
    }
    // Sewing
    int sewing = rand() % 20;
    if(sewing < 3){
        cout << "Sewing " << this->getName() << " (" << position[0] << "," << position[1] << ").\n";
        int *newPosition = FindUnoccupiedField();
        if(newPosition[0] == -1 && newPosition[1] == -1){
            delete newPosition;
            return;
        }
        else{
            reproduction(newPosition[0], newPosition[1]);
        }
    }
};

Organism *Hogweed::reproduction(int x, int y){
    return new Hogweed(world, x, y, 1, true);
};

Hogweed::~Hogweed(){
};