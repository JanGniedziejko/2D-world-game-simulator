#ifndef Hogweed_h
#define Hogweed_h

#include <stdio.h>
#include "Plant.h"

class Hogweed : public Plant {
    public:
        Hogweed(World* world, int x, int y, int age, bool newBorn);
        void draw() override;
        void action() override;
        string getName() override;
        Organism *reproduction(int x, int y) override;
        ~Hogweed() override;
};

#endif