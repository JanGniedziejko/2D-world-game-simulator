#include <conio.h>
#include "Human.h"

Human::Human(World* world, int x, int y, int age)
    : Animal(world, 5, 4, x, y, age, false) {

};

void Human::draw() {
    printf("$");
};

string Human::getName() {
    return ("Human");
};

void Human::action() {
    if (magical_cld > 0) { strength--; magical_cld--; }
    age++;
    int move;
    world->SetStrength(this->getStrength());

    // Zdobycie pozycji
    int newPosition[2];
    newPosition[0] = position[0];
    newPosition[1] = position[1];

    printf("Make your move: ");
    if (world->getTurn() == 1) {
        move = getchar();
    }
    move = getchar();

    if (move == 97) {
        newPosition[0]--;
    }
    else if (move == 100) {
        newPosition[0]++;
    }
    else if (move == 119) {
        newPosition[1]--;
    }
    else if (move == 115) {
            newPosition[1]++;
    }
    else if (move == 114) {
        int* temp = specialAbility();
        if (temp[0] == -1) return;
        newPosition[0] = temp[0];
        newPosition[1] = temp[1];
    }
    else if (move == 80 || move == 112) {
        magical_potion();
        return;
    }
    else if (move == 116 || move == 84) {
        world->saveWorld();
        _getch();
        exit(0);
    }
    printf("\n");

    // Can't move out of the board
    if ((newPosition[0] < 0 || newPosition[1] < 0) || (newPosition[0] >= world->getWidth()) || (newPosition[1] >= world->getHeight())) {
        printf("\nWARNING --> You can't move like this!\n");
        return;
    }

    // Changing position
    if (world->Organism_board[newPosition[0]][newPosition[1]] == nullptr) {
        world->Organism_board[newPosition[0]][newPosition[1]] = this;
        world->Organism_board[position[0]][position[1]] = nullptr;
        position[0] = newPosition[0];
        position[1] = newPosition[1];
    }
    else {
        collision(world->Organism_board[newPosition[0]][newPosition[1]]);
    }
};
// Teleport to a random unoccupied field
int* Human::specialAbility() {
    int* possitionss = new int[2];
    possitionss[0] = -1;
    if (world->getHumanCooldown() == 0) {
        printf("\nTeleporting");
        for (int i = 0; i < 3; i++) {
            //sleep(1);
            printf(" .");
        }
        do {
            possitionss[0] = rand() % world->getWidth();
            possitionss[1] = rand() % world->getHeight();
        } while (world->Organism_board[possitionss[0]][possitionss[1]] != nullptr);
        world->setHumanCooldown(5);
        return possitionss;
    }
    else {
        printf("\nYour Special Ability isn't ready yet\n");
        return possitionss;
    }
};
void Human::setStrength(int str) {
    strength += str;
}
void Human::magical_potion() {
    if (world->getHumanCooldown() == 0) {
        setStrength(6);
        magical_cld = 6;
        printf("You used magical potion and now your strength is increased by 5\n");
        world->setHumanCooldown(6);
    }
    else {
        printf("\nYour Special Ability isn't ready yet\n");
    }
};

Organism* Human::reproduction(int x, int y) {
    return new Human(world, x, y, 1);
};

Human::~Human() {
    world->SetEnd();
};