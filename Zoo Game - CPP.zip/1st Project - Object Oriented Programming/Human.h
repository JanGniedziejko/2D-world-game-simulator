#ifndef Human_h
#define Human_h

#include <stdio.h>
#include "Animal.h"

class Human : public Animal {
    public:
        int magical_cld = 0;
        Human(World* world, int x, int y, int age);
        void draw() override;
        void action() override;
        string getName() override;
        int* specialAbility();
        void setStrength(int str);
        void magical_potion();
        Organism * reproduction(int x, int y) override;
        ~Human();
};

#endif