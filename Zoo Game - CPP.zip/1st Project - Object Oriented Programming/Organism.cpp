#include "Organism.h"

Organism::Organism(World* world, int strength, int initiative, int x, int y, int age, bool newBorn)
: world(world), strength(strength), initiative(initiative), age(age), newBorn(newBorn){
    this->position[0] = x;
    this->position[1] = y;
    
    if(x == -1 && y == -1) return;
    world->Organism_board[x][y] = this;
    world->All_organisms->add(this);
};
// changing organism's location into adjacent field
int *Organism::pathFindNewField(){
    int *returnPosition = new int[2];
    returnPosition[0] = position[0];
    returnPosition[1] = position[1];
    int field;
    bool outside;
    do{
        field = rand() % 4;
        outside = false;
        switch(field){
            case 0:   
                if(returnPosition[1] == 0){
                    outside = true;
                }
                else returnPosition[1]--;
                break;
            case 1:   
                if(returnPosition[0] == world->getWidth()-1){
                    outside = true;
                }
                else returnPosition[0]++;
                break;
            case 2:     
                if(returnPosition[1] == world->getHeight()-1){
                    outside = true;
                }
                else returnPosition[1]++;
                break;
            case 3:   
                if(returnPosition[0] == 0){
                    outside = true;
                }
                else returnPosition[0]--;
        }
    }while(outside);
    return returnPosition;
};

// The same as the previous function, but additionally checks if this field is unoccupied
int *Organism::FindUnoccupiedField(){
    int *returnPosition = new int[2];
    returnPosition[0] = position[0];
    returnPosition[1] = position[1];

    if((returnPosition[1] != 0) && (world->Organism_board[returnPosition[0]][returnPosition[1]-1] == nullptr)){
        returnPosition[1]--;
        return returnPosition;
    }
    else if((returnPosition[0] != world->getWidth() - 1) && (world->Organism_board[returnPosition[0]+1][returnPosition[1]] == nullptr)){
        returnPosition[0]++;
        return returnPosition;
    }
    else if((returnPosition[1] != world->getHeight() - 1) && (world->Organism_board[returnPosition[0]][returnPosition[1]+1] == nullptr)){
        returnPosition[1]++;
        return returnPosition;
    }
    else if((returnPosition[0] != 0) && (world->Organism_board[returnPosition[0]-1][returnPosition[1]] == nullptr)){
        returnPosition[0]--;
        return returnPosition;
    }

    // no empty fields nearby
    returnPosition[0] = -1;
    returnPosition[1] = -1;
    return returnPosition;
};

int Organism::getStrength(){
    return strength;
};

int Organism::getInitiative(){
    return initiative;
};

void Organism::setX(int x){
    position[0] = x;
};

int Organism::getX(){
    return position[0];
};

void Organism::setY(int y){
    position[1] = y;
};

int Organism::getY(){
    return position[1];
};

int Organism::getAge(){
    return age;
};

bool Organism::getNewBorn(){
    return newBorn;
};

// turtle ability
bool Organism::reflected(Organism *organism){
    return false;
};

Organism::~Organism(){};