#ifndef Organism_h
#define Organism_h

#include <iostream>
#include <string>
#include "World.h"

using namespace std;

class Organism {
    protected:
        World * world;                  
        int strength;                         
        int initiative;        
		int position[2];                        
		int age;                     
    public:
        bool newBorn;                     
        Organism(World *world, int strength, int initiative, int x, int y, int age, bool newBorn);
        virtual int *pathFindNewField();    
        int *FindUnoccupiedField();   
        
        int getStrength();
        int getInitiative();
        void setX(int x);
        void setY(int y);
        int getX();
        int getY();
        int getAge();
        bool getNewBorn();
    
        virtual bool is_animal() = 0;
        virtual bool reflected(Organism *organism);
        virtual Organism *reproduction(int x, int y) = 0;  

        virtual string getName() = 0;
        virtual void draw() = 0;
        virtual void action() = 0;
        virtual ~Organism();
};

#endif