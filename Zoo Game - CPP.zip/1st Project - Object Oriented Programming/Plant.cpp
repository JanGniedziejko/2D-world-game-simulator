#include "Plant.h"
using namespace std;

Plant::Plant(World * world, int strength, int x, int y, int age, bool newBorn)
: Organism(world, strength, 0, x, y, age, newBorn){};

void Plant::action(){
    if(this->getName().compare("Thistle")){
        age++;
    }
    // 15% likelihood
    int sewing = rand() % 20;
    if(sewing < 3){
        int *newPosition = FindUnoccupiedField();
        // if there is no empty fields
        if(newPosition[0] == -1 && newPosition[1] == -1){
            delete newPosition;
            return;
        }
        else{
            // if there is some empty fields
            reproduction(newPosition[0], newPosition[1]);
            cout << "Sewing " << this->getName() << " at (" << position[0] << "," << position[1] << ")\n";
        }
    }
};
bool Plant::is_animal() {
    return false;
};

Plant::~Plant(){};