#ifndef Plant_h
#define Plant_h

#include <stdio.h>
#include <stdlib.h>
#include "Organism.h"

class Plant : public Organism {
    public:
        Plant(World* world, int strength, int x, int y, int age, bool newBorn);
        bool is_animal();
        void action() override;
        ~Plant();
};

#endif