#include "Sheep.h"

Sheep::Sheep(World* world, int x, int y, int age, bool newBorn)
: Animal(world, 4, 4, x, y, age, newBorn){
    
};

void Sheep::draw(){
    printf("S");
};

string Sheep::getName(){
    return ("Sheep");
};

Organism *Sheep::reproduction(int x, int y){
    return new Sheep(world, x, y, 1, true);
};

Sheep::~Sheep(){
    
};
