#ifndef Sheep_h
#define Sheep_h

#include <stdio.h>
#include "Animal.h"

class Sheep : public Animal {
    public:
        Sheep(World* world, int x, int y, int age, bool newBorn);
        void draw() override;
        string getName() override;
        Organism* reproduction(int x, int y) override;
        ~Sheep() override;
};

#endif