#include "Thistle.h"

Thistle::Thistle(World* world, int x, int y, int age, bool newBorn)
: Plant(world, 0, x, y, age, newBorn){
    
};

void Thistle::draw(){
    printf("*");
};

string Thistle::getName(){
    return ("Thistle");
};

void Thistle::action(){
    age++;
    // 3 attempts to reproduce
    Plant::action();
    Plant::action();
    Plant::action();
};

Organism* Thistle::reproduction(int x, int y){
    return new Thistle(world, x, y, 1, true);
};

Thistle::~Thistle(){
    
};