#ifndef Thistle_h
#define Thistle_h

#include <stdio.h>
#include "Plant.h"

class Thistle : public Plant {
    public:
        Thistle(World* world, int x, int y, int age, bool newBorn);
        void draw() override;
        void action() override;
        string getName() override;
        Organism* reproduction(int x, int y) override;
        ~Thistle() override;
};

#endif