#include "Turtle.h"

Turtle::Turtle(World* world, int x, int y, int age, bool newBorn)
: Animal(world, 2, 1, x, y, age, newBorn){
    
};

void Turtle::draw(){
    printf("T");
};

string Turtle::getName(){
    return ("Turtle");
};

void Turtle::action(){
    age++;
    // 25% likelihood to move
    int move = rand() % 4;
    if(move == 0){
        Animal::action();
    }
};

// Turtle's special ability 
bool Turtle::reflected(Organism *organism){
    if (organism->getStrength() < 5) return true;
    return false;
};

Organism *Turtle::reproduction(int x, int y){
    return new Turtle(world, x, y, 1, true);
};

Turtle::~Turtle(){
    
};
