#ifndef Turtle_h
#define Turtle_h

#include <stdio.h>
#include "Animal.h"

class Turtle : public Animal {
    public:
        Turtle(World* world, int x, int y, int age, bool newBorn);
        void draw() override;
        void action() override;
        string getName() override;
        bool reflected(Organism *organism) override;
        Organism * reproduction(int x, int y) override;
        ~Turtle() override;
};

#endif