#include "Wolf.h"

Wolf::Wolf(World * world, int x, int y, int age, bool newBorn)
: Animal(world, 9, 5, x, y, age, newBorn){
    
};

void Wolf::draw(){
    printf("W");
};

string Wolf::getName(){
    return ("Wolf");
};

Organism *Wolf::reproduction(int x, int y){
    return new Wolf(world, x, y, 1, true);
};

Wolf::~Wolf(){
    
};
