#ifndef Wolf_h
#define Wolf_h

#include <stdio.h>
#include "Animal.h"

class Wolf : public Animal {
    public:
        Wolf(World* world, int x, int y, int age, bool newBorn);
        void draw() override;
        string getName() override;
        Organism* reproduction(int x, int y) override;
        ~Wolf() override;
};

#endif