#include "World.h" 
#include "Organism.h"    
#include "Animal.h"       
#include "Human.h"   
#include "Sheep.h" 
#include "CyberSheep.h"
#include "Wolf.h" 
#include "Fox.h"      
#include "Turtle.h" =
#include "Antelope.h"     
#include "Plant.h"        
#include "Grass.h"    
#include "Thistle.h"    
#include "Guarana.h"     
#include "Belladonna.h"  
#include "Hogweed.h" 
 
#include <conio.h>

Organisms::Organisms(int maxSize) : maxSize(maxSize){
    head = new OrganismNode;
    head->organism = nullptr;
    head->next = nullptr;
};

int Organisms::getMaxSize(){
    return maxSize;
};

int Organisms::Occupied(){
    return occupancy;
};

bool Organisms::add(Organism * organism){
    // checking if the board is not full yet
    if(occupancy >= maxSize){
        printf("Full board!\n");
        return false;
    }
    OrganismNode* new_organism = new OrganismNode;
    new_organism->organism = organism;
    new_organism->next = nullptr;
    
    OrganismNode* current = head;
    
    // Find the place in the List for new organism (based on age and initiative)
    while(current->next != nullptr){
        if(organism->getInitiative() > current->next->organism->getInitiative()){
            break;
        }
        else if(organism->getInitiative() == current->next->organism->getInitiative()){
            if(organism->getAge() >= current->next->organism->getAge()){
                break;
            }
        }
        current = current->next;
    }
    // adding new node between 2 previous ones
    new_organism->next = current->next;
    current->next = new_organism;
    occupancy++;
    return true;
};

void Organisms::remove(Organism *organism){
    //looking for particular organism in List
    OrganismNode *current = head;
    for(int i = 0; i < occupancy; i++){
        if(current->next->organism == organism){
            break;
        }
        current = current->next;
    }
    
    // Deleting organism
    current->next = current->next->next;
    delete organism;
    occupancy--;
};

Organisms::~Organisms(){
};

void World::place(Organism *organism, int x, int y){
    //placing new organisms
    int newPosition[2];
    if (x == -1 && y == -1) {
        newPosition[0] = rand() % getWidth();
        newPosition[1] = rand() % getHeight();
    }
    else {
        newPosition[0] = x;
        newPosition[1] = y;
    }
    if(Organism_board[newPosition[0]][newPosition[1]] == nullptr){
        organism->setX(newPosition[0]);
        organism->setY(newPosition[1]);
        Organism_board[newPosition[0]][newPosition[1]] = organism;
        if (!All_organisms->add(organism)) {
            this->SetEnd();
        }
    }
    else{
        delete organism;
    }
};

// Constructors
World::World(int w, int h) : w(w), h(h) {
    
    printf("Creating World...\n");
    srand(time(NULL));

    // Zaalokowanie przestrzeni dla organizmów
    Organism_board = new Organism **[w];
    for(int i = 0; i < w; i++){
        Organism_board[i] = new Organism *[h];
        for (int j = 0; j < h; j++) {
            Organism_board[i][j] = nullptr;
        }
    }

    // Wezwanie lookupu
    All_organisms = new Organisms(w*h);
    
    // Położenie człowieka na planszy
    place(new Human(this, -1, -1, 19), -1, -1);
    humanCooldown = 0;
    
    // Ustawienie wszystkich zwierząt na pozycjach
    place(new Sheep(this, -1, -1, 15, false), -1, -1);
    place(new Sheep(this, -1, -1, 17, false), -1, -1);
    place(new CyberSheep(this, -1, -1, 13, false), -1, -1);
    place(new Wolf(this, -1, -1, 12, false), -1, -1);
    place(new Wolf(this, -1, -1, 9, false), -1, -1);
    
    place(new Grass(this, -1, -1, 5, false), -1, -1);
    
    place(new Thistle(this, -1, -1, 2, false), -1, -1);

    place(new Guarana(this, -1, -1, 2, false), -1, -1);
    place(new Guarana(this, -1, -1, 3, false), -1, -1);
    
    
    place(new Belladonna(this, -1, -1, 2, false), -1, -1);

    place(new Hogweed(this, -1, -1, 1, false), -1, -1);
    place(new Fox(this, -1, -1, 4, false), -1, -1);
    place(new Fox(this, -1, -1, 8, false), -1, -1);
    
    place(new Turtle(this, -1, -1, 23, false), -1, -1);
    place(new Turtle(this, -1, -1, 19, false), -1, -1);
    
    place(new Antelope(this, -1, -1, 12, false), -1, -1);
    place(new Antelope(this, -1, -1, 6, false), -1, -1);
};
World::World(int w, int h, ifstream &file) : w(w), h(h) {
    
    printf("Saved world...\n",w,h);
    srand(time(NULL));

    // Setting each element of organism_board to null pointer
    Organism_board = new Organism **[w];
    for(int i = 0; i < w; i++){
        Organism_board[i] = new Organism *[h];
        for (int j = 0; j < h; j++) {
            Organism_board[i][j] = nullptr;
        }
    }
    //Creating List with organisms
    All_organisms = new Organisms(w*h);

    Organism *newEntity;
    string word;
    int x, y, old_Age, is_new_born;
    while(file >> word){
        file >> x >> y >> old_Age >> is_new_born;
        if(!word.compare("Antelope")){
            place(new Antelope(this, -1, -1, old_Age, is_new_born), x, y);
        }
        else if(!word.compare("Belladonna")){
            place(new Belladonna(this, -1, -1, old_Age, is_new_born), x, y);
        }
        else if(!word.compare("Dandelion")){
            place(new Thistle(this, -1, -1, old_Age, is_new_born), x, y);
        }
        else if(!word.compare("Fox")){
            place(new Fox(this, -1, -1, old_Age, is_new_born), x, y);
        }
        else if(!word.compare("Grass")){
            place(new Grass(this, -1, -1, old_Age, is_new_born), x, y);
        }
        else if(!word.compare("Guarana")){
            place(new Guarana(this, -1, -1, old_Age, is_new_born), x, y);
        }
        else if(!word.compare("Hogweed")){
            place(new Hogweed(this, -1, -1, old_Age, is_new_born), x, y);
        }
        else if(!word.compare("Human")){
            place(new Human(this, -1, -1, old_Age), x, y);
        }
        else if(!word.compare("Sheep")){
            place(new Sheep(this, -1, -1, old_Age, is_new_born), x, y);
        }
        else if(!word.compare("Turtle")){
            place(new Turtle(this, -1, -1, old_Age, is_new_born), x, y);
        }
        else if(!word.compare("Wolf")){
            place(new Wolf(this, -1, -1, old_Age, is_new_born), x, y);
        }
    }
};

int World::getWidth(){
    return w;
};

int World::getHeight(){
    return h;
};

int World::getTurn(){
    return turn;
}

int World::getHumanCooldown(){
    return humanCooldown;
}
void World::SetStrength(int strength) {
    humanStrength = strength;
}

void World::setHumanCooldown(int i){
    humanCooldown = i;
}

bool World::End(){
    return end;
}

void World::SetEnd(){
    end = true;
}

void World::setTurn(int turn){
    this->turn = turn;
}

void World::drawWorld(){
    printf("\n Turn: %d\t Your Strength: %d\t\t\t\t\tLegend:\n\n Board: +",turn,humanStrength);
    for (int i = 0; i < w-1; i++) printf("__");
    printf("_+\t\t\tW - up    |   S - down\n");
    for(int i=0;i < h; i++) {
        printf("\t|");
        for(int j = 0; j < w; j++){
            if(Organism_board[j][i] != nullptr){
                Organism_board[j][i]->draw();
                printf("|");
            }
            else{
                printf(" |");
            }
        }
        if (i == 0) printf("\t\t\tA - left  |   D - right\n");
        else if (i == 1) printf("\t\t\tT - save the game\n");
        else if (i == 3) printf("\t\t\tAnimals: | A - Antelope   | S - Sheep\n");
        else if (i == 4) printf("\t\t\tF - Fox  | C - CyberSheep | T - Turtle |  W - Wolf\n");
        else if (i == 6) printf("\t\t\tPlants:   | & - Hogweed | B - Belladonna\n");
        else if (i == 7) printf("\t\t\t# - Grass | G - Guarana | * - Thistle \n");
        else printf("\n");
    }
    printf("\t+");
    for (int i = 0; i < w-1; i++) printf("--");
    printf("+\n\n");
};

void World::makeTurn(){
    printf("Turn %d...\n", turn);
    
    OrganismNode *current = All_organisms->head->next;
    // decrement a cooldown for human's special ability each turn
    if(humanCooldown > 0){
        humanCooldown--;
    }

    while(current != nullptr) {
        // new borned organism can't move during their first turn
        if(current->organism->newBorn == true){
            current->organism->newBorn = false;
        }
        else{
            current->organism->action();
        }
        current = current->next;
    }
    _getch();
    turn++;
};

void World::saveWorld(){
    ofstream file;
    file.open("save.txt", ios::out);
    if(!file){
        return;
    }
    else{
        file << w << " " << h << " "<< turn << " " << humanCooldown <<"\n";
        OrganismNode *current = All_organisms->head->next;
        while(current != nullptr){
            file << current->organism->getName() << " " << current->organism->getX() << " " << current->organism->getY() << " " << current->organism->getAge() << " " << current->organism->getNewBorn() << "\n";
            current = current->next;
        }
        file.close();
        printf("State of the game saved in file called: save.txt\n");
    }
};

World::~World(){};