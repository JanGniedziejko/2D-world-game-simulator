#ifndef World_h
#define World_h

#include <iostream>
#include <fstream>      
#include <time.h>       

using namespace std;

class Organism;

struct OrganismNode{
    Organism* organism;
    OrganismNode* next;
};

class Organisms {
    private:
        int maxSize;
        int occupancy = 0;
    public:
        Organisms(int maxSize);
        OrganismNode* head;
        int getMaxSize();
        int Occupied();
        bool add(Organism *organism);
        void remove(Organism *organism);
        ~Organisms();
};

class World {
    private:
        int w,h;
        int turn = 1;
        int humanCooldown;
        bool end=false;
    public:
        Organism*** Organism_board;       // pointer to 2d array of pointers
        Organisms* All_organisms;         // storing all organisms in List
        int humanStrength = 5;

        World(int w, int h);                              
        World(int w, int h, ifstream &loadFile);  

        int getWidth();
        int getHeight();
        int getHumanCooldown();
        int getTurn();
        void SetStrength(int strength);
        bool End();
        void SetEnd();
        void setHumanCooldown(int i);
        void setTurn(int turn);

        void drawWorld();
        void makeTurn();
        void place(Organism *organism, int x, int y);

        void saveWorld();

        ~World();
};

#endif