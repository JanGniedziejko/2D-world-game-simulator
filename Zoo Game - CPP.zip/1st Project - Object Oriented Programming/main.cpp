#include <iostream>
#include <conio.h>
#include "World.h"

using namespace std;

int main(){
    system("cls");
    printf("\n\n");
    printf("\t+---------------------------------+\n");
    printf("\t                                   \n");
    printf("\t   Jan Gniedziejko Index: 193633   \n");
    printf("\t   N - New game                    \n");
    printf("\t   L - Load saved game             \n");
    printf("\t   ESC - quit                      \n");
    printf("\t                                   \n");
    printf("\t+---------------------------------+\n\n");
    int mode, width, height, playerInput;
    mode = _getch();

    if(mode == 78 || mode == 110){
        printf("\t\tWorld size : ");
        cin >> width >> height;
        World world(width, height);
        while(!world.End()){
            system("cls");
            world.drawWorld();
            world.makeTurn();
            playerInput = getchar();
            if(playerInput == 120){
                world.saveWorld();
                _getch();
            }
        }
        system("cls");
        world.drawWorld();
    }
    else if(mode == 76 || mode == 108){
        ifstream File;
        File.open("save.txt", ios::in);
        if(!File){
            printf("Didnt find a file.\n");
            exit(1);
        }
        int Turn, cld;
        File >> width >> height >> Turn >> cld;
        World savedWorld(width, height, File);
        
        savedWorld.setTurn(Turn);       
        savedWorld.setHumanCooldown(cld);  
        
        while(!savedWorld.End()){
            system("cls");
            savedWorld.drawWorld();
            savedWorld.makeTurn();
            playerInput = getchar();
            if(playerInput == 120){
                savedWorld.saveWorld();
                getchar();
                getchar();
            }
        }
        // Koniec gry, pokaz świata
        system("cls");
        savedWorld.drawWorld();
    }
    else{
        exit(1);
    }

    // Koniec gry
    printf("GAME OVER!\n");
    _getch();
    return 0;
};