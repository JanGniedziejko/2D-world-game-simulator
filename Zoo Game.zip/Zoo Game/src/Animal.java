import java.awt.*;
import java.util.Objects;

public abstract class Animal extends Organism{
    public Animal(World world, int strength, int initiative, int x, int y, int age, boolean baby ){
        super(world,strength,initiative,x,y,age,baby);
    }
    public boolean sameSpecies(Organism organism){
        return (Objects.equals(this.getName(), organism.getName()));
    }
    public void breed(){
        if (!Objects.equals(this.getName(),"Human")) {
            int[] newPosition = FindUnoccupiedField();
            if (newPosition[0] == -1 && newPosition[1] == -1) {
                getWorld().add("No empty fields around\n");
                return;
            }
            reproduction(newPosition[0], newPosition[1]); // if there is a free field nearby, then placing new organism there
        }
    }
    public boolean is_animal(){
        return true;
    }
    public abstract String getName();
    public abstract String draw();
    public void action(){
        if(!Objects.equals(getName(), "Turtle")) {
            incrementAge();
        }
        int[] newPosition = pathFindNewField();
        if(getWorld().getOrganismBoard(newPosition[0],newPosition[1]) == null) {
            getWorld().changeCoordsOnBoard(newPosition[0], newPosition[1], this);
            setX(newPosition[0]);
            setY(newPosition[1]);
        } else {
            collision(getWorld().getOrganismBoard(newPosition[0],newPosition[1]));
        }
    }
    public void collision(Organism colliding){
        if(Objects.equals(this.getName(), "Human") && sameSpecies(colliding)) return;
        if(!Objects.equals(this.getName(), "Human")){
            if(sameSpecies(colliding))
            {
                getWorld().add("Breeding of "+ this.getName() +" at ("+getX()+","+getY()+")\n");
                breed();
                return;
            }
        }
        if(colliding.reflected(this)){
            getWorld().add("Turtle reflected "+ this.getName()+"'s attack at ("+getX()+","+getY()+")\n");
            return;
        }
        else if(colliding.is_animal()) {
            getWorld().add("Fight between " + this.getName() + " and " + colliding.getName() + " at (" + getX() + "," + getY() + ")\n");
        }
        if (Objects.equals(this.getName(),"CyberSheep") && Objects.equals(colliding.getName(),"Hogweed")) {
            getWorld().changeCoordsOnBoard(colliding.getX(),colliding.getY(),this);
            getWorld().removeFromList(colliding);
        }
        else if (this.getStrength() >= colliding.getStrength() && !Objects.equals(colliding.getName(), "Hogweed")) {
            getWorld().add(this.getName() + " won\n");
            if(Objects.equals(colliding.getName(),"Guarana")){
                getWorld().add(this.getName() + " ("+getX()+","+getY()+") strength +3\n");
                incrementStrength(3);
            }
            getWorld().removeOrganismFromBoard(getX(),getY());
            setX(colliding.getX());
            setY(colliding.getY());
            getWorld().addOrganismToBoard(this,getX(),getY());
            getWorld().removeFromList(colliding);
        }
        else {
            getWorld().add(this.getName() + " lost\n");
            getWorld().removeOrganismFromBoard(getX(),getY());
            getWorld().removeFromList(this);
        }
    }
}
