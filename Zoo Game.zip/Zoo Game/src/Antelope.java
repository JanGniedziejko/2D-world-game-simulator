import java.awt.*;
import java.util.Random;
public class Antelope extends Animal {
    public Antelope(World world, int x, int y, int age, boolean baby){
        super(world, 4, 4, x, y, age, baby);
    }
    @Override public int[] pathFindNewField(){
        int[] returnPosition = new int[2];
        returnPosition[0] = this.getX();
        returnPosition[1] = this.getY();
        int field;
        boolean invalidMove;
        Random rand = new Random();
        do {
            field = rand.nextInt(8);
            invalidMove = false;
            switch (field) {
                case 0 -> {
                    if (returnPosition[1] == 0)
                        invalidMove = true;
                    else returnPosition[1]--;
                }
                case 1 -> {
                    if (returnPosition[0] == getWorld().getWidth() - 1)
                        invalidMove = true;
                    else returnPosition[0]++;
                }
                case 2 -> {
                    if (returnPosition[1] == getWorld().getHeight() - 1)
                        invalidMove = true;
                    else returnPosition[1]++;
                }
                case 3 -> {
                    if (returnPosition[0] == 0)
                        invalidMove = true;
                    else returnPosition[0]--;
                }
                case 4 -> {
                    if (returnPosition[1] <= 1)
                        invalidMove = true;
                    else returnPosition[1] -= 2;
                }
                case 5 -> {
                    if (returnPosition[0] >= getWorld().getWidth() - 2)
                        invalidMove = true;
                    else returnPosition[0] += 2;
                }
                case 6 -> {
                    if (returnPosition[1] >= getWorld().getHeight() - 2)
                        invalidMove = true;
                    else returnPosition[1] += 2;
                }
                case 7 -> {
                    if (returnPosition[0] <= 1)
                        invalidMove = true;
                    else returnPosition[0] -= 2;
                }
            }

        }while(invalidMove);
        return returnPosition;
    }
    public String draw(){
        return("A");
    }
    public String getName(){
        return ("Antelope");
    }
    public void collision(Organism colliding){}
    public Organism reproduction(int x, int y) {
        return new Antelope(getWorld(),x,y,1,true);
    }

}
