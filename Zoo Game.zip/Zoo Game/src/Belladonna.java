import java.awt.*;

public class Belladonna extends Plant{
    public Belladonna(World world,int x, int y, int age, boolean baby){
        super(world,99,x,y,age,baby);
    }
    public String draw(){
        return("B");
    }
    public String getName(){
        return("Belladonna");
    }
    public Organism reproduction(int x, int y){
        return new Belladonna(getWorld(),x,y,1,true);
    }
}
