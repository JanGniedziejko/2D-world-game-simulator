import java.awt.*;
import java.util.Objects;

public class CyberSheep extends Animal{
    public CyberSheep(World world, int x, int y, int age, boolean baby) {
        super(world, 11, 4, x, y, age, baby);
    }

    public String draw() {
        return("C");
    }

    public String getName() {
        return ("CyberSheep");
    }

    public void action() {
        int[] newPosition = new int[2];
        int min = 200, temp;
        int chase_X = 0, chase_Y = 0;
        OrganismNode current = getWorld().headOfOrganisms().next;
        while (current != null) {
            if(!current.organism.is_animal() && current.organism.getStrength()==10) { // Looking for Hogweed
                temp = Math.abs(this.getX() - current.organism.getX()) + Math.abs(this.getY() - current.organism.getY());
                if (temp < min) {
                    min = temp;
                    chase_X = current.organism.getX();
                    chase_Y = current.organism.getY();
                }
            }
            current = current.next;
        }
        if (min == 200) {
            int[] new_coords = this.pathFindNewField();
            newPosition[0] = new_coords[0];
            newPosition[1] = new_coords[1];
        }
        else if (Math.abs(this.getX() - chase_X) >= Math.abs(this.getY() - chase_Y)) {
            if (this.getX() - chase_X > 0) {
                newPosition[0] = this.getX() - 1;
                newPosition[1] = this.getY();
            }
            else if (this.getX() - chase_X < 0) {
                newPosition[0] = this.getX() + 1;
                newPosition[1] = this.getY();
            }
        }
        else {
            if (this.getY() - chase_Y > 0) {
                newPosition[0] = this.getX();
                newPosition[1] = this.getY() - 1;
            }
            else if (this.getY() - chase_X < 0) {
                newPosition[0] = this.getX();
                newPosition[1] = this.getY() + 1;
            }
        }

        if (getWorld().getOrganismBoard(newPosition[0],newPosition[1]) == null) {
            getWorld().changeCoordsOnBoard(newPosition[0],newPosition[1],this);
            setX(newPosition[0]);
            setY(newPosition[1]);
        }
        else {
            collision(getWorld().getOrganismBoard(newPosition[0],newPosition[1]));
            setX(newPosition[0]);
            setY(newPosition[1]);
        }
    }

    public Organism reproduction(int x, int y) {
        return new CyberSheep(getWorld(), x, y, 1, true);
    }
}
