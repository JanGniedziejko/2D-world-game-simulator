import java.awt.*;

public class Fox extends Animal {
    public Fox(World world, int x, int y, int age, boolean baby){
        super(world, 3,7,x,y,age,baby);
    }

    public String draw(){
        return("F");
    };

    public String getName(){
        return ("Fox");
    };

    public void action(){
        this.incrementAge();
        int[] newPosition = pathFindNewField();
        if(getWorld().getOrganismBoard(newPosition[0],newPosition[1]) == null){
            getWorld().changeCoordsOnBoard(newPosition[0],newPosition[1],this);
            this.setX(newPosition[0]);
            this.setY(newPosition[1]);
        }
        else{
            // moves if and only if the fox can win a fight with an organism in the neighbouring field
            if(getWorld().getOrganismBoard(newPosition[0],newPosition[1]).getStrength() <= this.getStrength()){
                collision(getWorld().getOrganismBoard(newPosition[0],newPosition[1]));
            }else{
                getWorld().add("Fox is sensing something dangerous at (" + newPosition[0] + "," + newPosition[1] + ")\n");
            }
        }
    };

    public Organism reproduction(int x, int y){
        return new Fox(getWorld(), x, y, 1, true);
    };
}
