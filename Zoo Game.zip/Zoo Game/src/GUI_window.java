import javax.swing.*;
import javax.swing.border.Border;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class GUI_window extends JFrame implements KeyListener {
    private World world;
    private JPanel legend;
    private JPanel organisms_desc;
    private JPanel movement_desc;
    private JPanel buttons;
    private JButton makeTurn;
    private JButton saveGame;
    private JPanel logs;
    private JPanel board;
    private int width;
    private int height;
    private JTextArea logsTextArea;
    private JScrollPane scrollPane;

    private boolean duringTurn = false;

    public GUI_window(int width, int height){
        this.width = width;
        this.height = height;
        world = new World(width,height);
        world.setJFrame(this);

        this.setTitle("Jan Gniedziejko 193633");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setResizable(false);
        this.setSize(1400,860);


        Border border = BorderFactory.createLineBorder(Color.black,3,true);

        add_legend();
        add_buttons();
        add_logs();
        add_board();
        legend.setBorder(border);
        buttons.setBorder(border);
        logs.setBorder(border);
        board.setBorder(border);
        this.add(legend, BorderLayout.WEST);
        this.add(buttons, BorderLayout.SOUTH);
        this.add(logs, BorderLayout.EAST);
        this.add(board, BorderLayout.CENTER);

        this.setVisible(true);
        board.setFocusable(true);
        board.requestFocusInWindow();
        board.addKeyListener(this);
    }

    public GUI_window(String filename){
        this.width = width;
        this.height = height;
        world = new World(filename);
        world.setJFrame(this);
        this.width = world.getWidth();
        this.height = world.getHeight();

        this.setTitle("Jan Gniedziejko 193633");
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setResizable(false);
        this.setSize(1400,860);

        Border border = BorderFactory.createLineBorder(new Color(0x816743),3,true);

        add_legend();
        add_buttons();
        add_board();
        add_logs();

        legend.setBorder(border);
        buttons.setBorder(border);
        logs.setBorder(border);
        board.setBorder(border);

        this.add(legend, BorderLayout.WEST);
        this.add(buttons, BorderLayout.SOUTH);
        this.add(logs, BorderLayout.EAST);
        this.add(board, BorderLayout.CENTER);

        this.setVisible(true);
        board.setFocusable(true);
        board.requestFocusInWindow();
        board.addKeyListener(this);
    }
    public void add_legend(){
        ImageIcon icon = new ImageIcon("Zoo.png");
        Image resizedImage = icon.getImage().getScaledInstance(205, 155, Image.SCALE_SMOOTH);
        ImageIcon resizedIcon = new ImageIcon(resizedImage);
        JLabel image = new JLabel(resizedIcon);
        this.add(image);
        image.setBounds(20,0,210,160);

        legend = new JPanel();
        legend.setLayout(new BoxLayout(legend, BoxLayout.Y_AXIS));

        movement_desc = new JPanel();
        organisms_desc = new JPanel();
        
        JLabel[] movement_lines = new JLabel[6];
        movement_lines[0] = new JLabel("How to move?");
        movement_lines[1] = new JLabel(" ");
        movement_lines[2] = new JLabel(" W --> UP");
        movement_lines[3] = new JLabel(" A --> LEFT");
        movement_lines[4] = new JLabel(" S --> DOWN");
        movement_lines[5] = new JLabel(" D --> RIGHT");

        JLabel[] organisms_lines = new JLabel[17];
        organisms_lines[0]= new JLabel("Animals:");
        organisms_lines[1]= new JLabel(" ");
        organisms_lines[2]= new JLabel(" A - Antelope");
        organisms_lines[3]= new JLabel(" S - Sheep");
        organisms_lines[4]= new JLabel(" F - Fox");
        organisms_lines[5]= new JLabel(" C - CyberSheep");
        organisms_lines[6]= new JLabel(" W - Wolf");
        organisms_lines[7]= new JLabel(" T - Turtle");
        organisms_lines[8]= new JLabel(" ");
        organisms_lines[9]= new JLabel(" ");
        organisms_lines[10]= new JLabel("Plants:");
        organisms_lines[11]= new JLabel(" ");
        organisms_lines[12]= new JLabel(" # - Hogweed");
        organisms_lines[13]= new JLabel(" B - Belladonna");
        organisms_lines[14]= new JLabel(" w - Grass");
        organisms_lines[15]= new JLabel(" G - Guarana");
        organisms_lines[16]= new JLabel(" * - Sow Thistle");

        movement_lines[0].setFont(new Font("Comic Sans",Font.PLAIN | Font.BOLD,16));
        movement_desc.add(movement_lines[0]);
        for(int i=1;i<6;i++){
            movement_lines[i].setFont(new Font("Comic Sans",Font.PLAIN,16));
            movement_desc.add(movement_lines[i]);
        }
        for(int i=0; i<17;i++){
            if(i%10 == 0) organisms_lines[i].setFont(new Font("Comic Sans",Font.PLAIN | Font.BOLD,16));
            else organisms_lines[i].setFont(new Font("Comic Sans",Font.PLAIN,16));
            organisms_desc.add(organisms_lines[i]);
        }

        movement_desc.setLayout(new BoxLayout(movement_desc, BoxLayout.Y_AXIS));
        organisms_desc.setLayout(new BoxLayout(organisms_desc, BoxLayout.Y_AXIS));
        movement_desc.setBackground(null);
        organisms_desc.setBackground(null);
        organisms_desc.setAlignmentX(Component.CENTER_ALIGNMENT);
        organisms_desc.setAlignmentY(Component.CENTER_ALIGNMENT);
        movement_desc.setAlignmentX(Component.CENTER_ALIGNMENT);
        movement_desc.setAlignmentY(Component.CENTER_ALIGNMENT);

        legend.add(Box.createVerticalStrut(180));
        legend.add(movement_desc);
        legend.add(Box.createVerticalStrut(40));
        legend.add(organisms_desc);
        legend.setBackground(new Color(0xfaedcd));
        legend.setPreferredSize(new Dimension(250,100));
    }
    public void add_buttons(){
        buttons = new JPanel();
        buttons.setBackground(new Color(0xfefae0));
        buttons.setLayout(new FlowLayout(FlowLayout.CENTER,100,10));
        makeTurn = new JButton("Next Turn");
        saveGame = new JButton("Save this game");
        makeTurn.setFont(new Font("Comic Sans", Font.PLAIN | Font.BOLD,20));
        saveGame.setFont(new Font("Comic Sans", Font.PLAIN | Font.BOLD,20));
        makeTurn.addActionListener(e -> {
            duringTurn=true;
            board.requestFocusInWindow();
        });
        saveGame.addActionListener(e -> {
            world.saveWorldState();
            saveGame.setEnabled(false);
            makeTurn.setEnabled(false);
        });
        makeTurn.setPreferredSize(new Dimension(300, 80)); // Set preferred size for makeTurn button
        saveGame.setPreferredSize(new Dimension(300, 80));
        buttons.add(makeTurn);
        buttons.add(saveGame);
        buttons.setPreferredSize(new Dimension(100, 100));
    }
    public void add_logs(){
        logs = new JPanel();
        logs.setBackground(new Color(0xfaedcd));
        logs.setPreferredSize(new Dimension(250,100));
        logsTextArea = new JTextArea();
        logsTextArea.setEditable(false);
        Font font = new Font("Comic Sans", Font.PLAIN | Font.BOLD, 15);
        logsTextArea.setFont(font);
        logsTextArea.setLineWrap(true);
        logsTextArea.setWrapStyleWord(true);

        scrollPane = new JScrollPane(logsTextArea);
        scrollPane.setAlignmentX(CENTER_ALIGNMENT);
        scrollPane.setAlignmentY(CENTER_ALIGNMENT);
        scrollPane.setPreferredSize(new Dimension(250, 500));

        logs.setLayout(new BoxLayout(logs, BoxLayout.Y_AXIS));
        logs.add(Box.createVerticalGlue());
        logs.add(scrollPane);
        logs.add(Box.createVerticalGlue());
    }
    public void print_logs() {
        String logsText = world.getLogs();
        logsTextArea.setText(logsText);
        logsTextArea.setCaretPosition(logsTextArea.getDocument().getLength());

        JScrollBar verticalScrollBar = scrollPane.getVerticalScrollBar();
        verticalScrollBar.setValue(verticalScrollBar.getMaximum());
    }
    public void add_board() {
        board = new JPanel();
        board.setBackground(new Color(0xccd5ae));
        board.setPreferredSize(new Dimension(200,100));
        for(int i=0;i<height;i++){
            for(int j=0;j<width;j++){
                board.add(world.Organism_button[j][i]);
            }
        }
        board.setLayout(new GridLayout(height,width));
    }
    public void addOrganismToBoard(int x, int y){
        PickOrganismForButton srutututu = new PickOrganismForButton(world,x,y);
    }

    @Override
    public void keyTyped(KeyEvent e) {
    }

    @Override
    public void keyPressed(KeyEvent e) {
    }

    @Override
    public void keyReleased(KeyEvent e) {
        if(duringTurn){
            world.setMove(e.getKeyCode());
            world.makeTurn();
            print_logs();
            world.EndGame();
            duringTurn=false;
        }
    }
    public void disableButtons(){
        saveGame.setEnabled(false);
        makeTurn.setEnabled(false);
    }
}
