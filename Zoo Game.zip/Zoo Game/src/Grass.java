import java.awt.*;

public class Grass extends Plant{
    public Grass(World world, int x, int y, int age, boolean baby){
        super(world, 0, x, y, age, baby);
    }

    public String draw(){
        return("w");
    }

    public String getName(){
        return ("Grass");
    }

    public Organism reproduction(int x, int y){
        return new Grass(getWorld(), x, y, 1, true);
    }
}
