import java.awt.*;

public class Guarana extends Plant{
    public Guarana(World world, int x, int y, int age, boolean baby){
        super(world,0,x,y,age,baby);
    }
    public String draw(){
        return("G");
    }
    public String getName(){
        return("Guarana");
    }
    public Organism reproduction(int x, int y){
        return new Guarana(getWorld(),x,y,1,true);
    }
}
