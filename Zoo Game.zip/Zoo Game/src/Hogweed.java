import java.awt.*;
import java.util.Objects;
import java.util.Random;

public class Hogweed extends Plant{
    public Hogweed(World world, int x, int y, int age, boolean baby){
        super(world,10,x,y,age,baby);
    }
    public String draw(){
        return("#");
    }
    public String getName(){
        return ("Hogweed");
    }
    @Override public void action(){
        int[] currentPosition = new int[2];
        int[] horiz =  {0, 1, 0, -1};
        int[] vertic = {-1 , 0 , 1 , 0};

        for(int i=0;i<4;i++){
            currentPosition[0] = getX() + horiz[i];
            currentPosition[1] = getY() + vertic[i];
            if((currentPosition[0] < 0 || currentPosition[1] < 0) || (currentPosition[0] >= getWorld().getWidth() || currentPosition[1] >= getWorld().getHeight())) {
                continue;
            }
            else {
                if(getWorld().getOrganismBoard(currentPosition[0],currentPosition[1]) != null){
                    if(!Objects.equals(getWorld().getOrganismBoard(currentPosition[0],currentPosition[1]).getName(),"CyberSheep")){
                        if(getWorld().getOrganismBoard(currentPosition[0],currentPosition[1]).is_animal()){
                            getWorld().removeFromList(getWorld().getOrganismBoard(currentPosition[0],currentPosition[1]));
                            getWorld().removeOrganismFromBoard(currentPosition[0],currentPosition[1]);
                        }
                    }

                }
            }
        }
        //Sewing
        super.action();

    }
    public Organism reproduction(int x, int y){
        return new Hogweed(getWorld(),x,y,1,true);
    }
}
