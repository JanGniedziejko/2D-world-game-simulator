
public class Human extends Animal  {
    private int magical_cld = 0,move = 0;
    public Human(World world, int x, int y,int power, int age){
        super(world,power,4,x,y,age,false);
    }
    public Human(World world, int x, int y,int power, int age, int cld){

        super(world,power,4,x,y,age,false);
        magical_cld = cld;
    }

    public String draw(){
        return("H");
    }
    public String getName(){
        return("Human");
    }
    public void setMove(char move){
        this.move = move;
    }
    @Override public void action(){
        if(magical_cld > 0) {
            setStrength(-1);
            magical_cld--;
        }
        incrementAge();
        getWorld().setStrength(this.getStrength());
        int[] newPosition = new int[2];
        newPosition[0] = getX();
        newPosition[1] = getY();
        getWorld().getJFrame().requestFocus();
        move = getWorld().getMove();
        if( move == 38){
            newPosition[1]--;
        } else if ( move == 39){
            newPosition[0]++;
        } else if ( move == 40) {
            newPosition[1]++;
        } else if ( move == 37) {
            newPosition[0]--;
        } else if ( move == 82) {
            magical_potion();
            getWorld().setStrength(this.getStrength());
            return;
        }

        if((newPosition[0] < 0 || newPosition[1] < 0) || (newPosition[0] >= getWorld().getWidth() || newPosition[1] >= getWorld().getHeight())){
            getWorld().add("WARNING --> You can't move there!");
            return;
        }

        if(getWorld().getOrganismBoard(newPosition[0],newPosition[1]) == null){
            getWorld().changeCoordsOnBoard(newPosition[0],newPosition[1],this );
            setX(newPosition[0]);
            setY(newPosition[1]);
        }
        else {
            collision(getWorld().getOrganismBoard(newPosition[0],newPosition[1]));
        }
        getWorld().setStrength(this.getStrength());
    }
    public void magical_potion(){
        if(getWorld().getHuman_cld() == 0){
            setStrength(5);
            magical_cld=5;
            getWorld().add("You've used magical potion!!!\n");
            getWorld().setHuman_cld(6);
        }
        else {
            getWorld().add("Your Special Ability isn't ready yet");
        }
    }

    @Override public Organism reproduction(int x, int y) {
        return null;
    }
}
