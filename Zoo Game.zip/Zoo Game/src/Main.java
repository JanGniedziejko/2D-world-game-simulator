public class Main {
    public static void main(String[] args) {
        Settings game = new Settings();
    }
}