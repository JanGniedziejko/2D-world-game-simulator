import java.awt.*;
import java.util.Random;
public abstract class Organism {
    private int strength;
    private World world;
    private int initiative;
    private int[] position = new int[2];
    private int age;
    private boolean baby;

    public Organism(World world, int strength, int initiative, int x, int y, int age, boolean baby){
        this.world = world;
        this.position[0] = x;
        this.position[1] = y;
        this.strength = strength;
        this.baby = baby;
        this.age = age;
        this.initiative = initiative;

        if(x == -1 || y == -1) return;
        world.addOrganismToBoard(this,x,y);
        world.addToList(this);
    }
    public int[] pathFindNewField() {
        int[] returnPosition = new int[2];
        int field;
        boolean outside;
        returnPosition[0] = position[0];
        returnPosition[1] = position[1];
        Random rand = new Random();
        do{
            field = rand.nextInt(4);
            outside = false;
            switch(field){
                case 0:
                    if(returnPosition[1] == 0){
                        outside = true;
                    }
                    else returnPosition[1]--;
                    break;
                case 1:
                    if(returnPosition[0] == world.getWidth()-1){
                        outside = true;
                    }
                    else returnPosition[0]++;
                    break;
                case 2:
                    if(returnPosition[1] == world.getHeight()-1){
                        outside = true;
                    }
                    else returnPosition[1]++;
                    break;
                case 3:
                    if(returnPosition[0] == 0){
                        outside = true;
                    }
                    else returnPosition[0]--;
            }
        }while(outside);
        return returnPosition;

    }
    public int[] FindUnoccupiedField(){
        int[] returnPosition = new int[2];
        returnPosition[0] = position[0];
        returnPosition[1] = position[1];

        if((returnPosition[1] != 0) && world.getOrganismBoard(returnPosition[0],returnPosition[1]-1) == null){
            returnPosition[1]--;
            return returnPosition;
        }
        else if((returnPosition[0] != world.getWidth() - 1) && world.getOrganismBoard(returnPosition[0]+1, returnPosition[1]) == null){
            returnPosition[0]++;
            return returnPosition;
        }
        else if((returnPosition[1] != world.getHeight() - 1) && world.getOrganismBoard(returnPosition[0], returnPosition[1]+1) == null){
            returnPosition[1]++;
            return returnPosition;
        }
        else if((returnPosition[0] != 0) && world.getOrganismBoard(returnPosition[0] - 1, returnPosition[1]) == null){
            returnPosition[0]--;
            return returnPosition;
        }
        returnPosition[0] = -1;
        returnPosition[1] = -1;
        return returnPosition;
    }

    public int getStrength(){
        return strength;
    }
    public int getInitiative(){
        return initiative;
    }
    public int getX(){
        return position[0];
    }
    public int getY(){
        return position[1];
    }
    public int getAge(){
        return age;
    }
    public World getWorld() {
        return world;
    }
    public boolean getNewBorn(){
        return baby;
    }
    public void noBaby() { baby = false;}
    public void setX(int x){
        position[0] = x;
    }
    public void setY(int y){
        position[1] = y;
    }
    public void setAge(int age) { this.age = age;}
    public void incrementAge() { age++; }
    public void setStrength(int str) { strength += str;}
    public void incrementStrength(int plus) {strength += plus;}
    public boolean reflected(Organism organism) { return false; }

    public abstract boolean is_animal();

    public abstract Organism reproduction(int x, int y);

    public abstract String getName();
    public abstract String draw();
    public abstract void action();
}

