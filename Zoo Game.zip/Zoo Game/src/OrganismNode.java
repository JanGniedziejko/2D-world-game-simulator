public class OrganismNode {
    public Organism organism;
    public OrganismNode next;

    public OrganismNode(Organism organism) {
        this.organism = organism;
        this.next = null;
    }
}
