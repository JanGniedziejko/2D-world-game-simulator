import java.util.LinkedList;
import java.util.List;
import java.util.Objects;

public class Organism_Container {
    private OrganismNode head;
    private int maxSize;
    private int occupancy=0;

    public boolean add(Organism organism) {
        if(occupancy >= maxSize) return false;
        OrganismNode newNode = new OrganismNode(organism);
        if (this.head == null) {
            this.head = newNode;
            return true;
        }

        // Iterate over the linked list to find the correct position
        OrganismNode curr = this.head;
        OrganismNode prev = null;
        while (curr.next != null) {
            if(organism.getInitiative() > curr.next.organism.getInitiative()){
                break;
            }
            else if (organism.getInitiative() == curr.next.organism.getInitiative()){
                if(organism.getAge() >= curr.next.organism.getAge()){
                    break;
                }
            }
            prev = curr;
            curr = curr.next;
        }
        newNode.next = curr.next;
        curr.next = newNode;
        occupancy++;
        return true;
    }
    public int getMaxSize(){ return maxSize; }
    public int getOccupancy() { return occupancy; }
    public Organism_Container(int max){
        maxSize = max;
        head = null;
    }
    public void remove(Organism organism){
        OrganismNode current = this.head;
        if(organism == current.organism){
            this.head = current.next;
            return;
        }
        for(int i=0;i<occupancy;i++){
            if(current.next.organism == organism){
                break;
            }
            current = current.next;
        }
        if(Objects.equals(organism.getName(),"Human")){
        }
        current.next = current.next.next;
        occupancy--;
    }

    public OrganismNode getHead(){
        return head;
    }
}
