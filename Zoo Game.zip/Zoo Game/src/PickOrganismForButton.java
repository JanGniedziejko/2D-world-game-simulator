import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.DataInput;

public class PickOrganismForButton extends JFrame implements ActionListener {
    private JRadioButton[] OrganismButtons;
    private World world;
    private int x;
    private int y;
    public PickOrganismForButton(World world,int x, int y){
        this.x = x;
        this.y = y;
        this.world = world;
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        this.setSize(new Dimension(200,200));
        int window_x = screenSize.width - getWidth()/2;
        int window_y = screenSize.height/2 - getHeight();
        this.setLayout(new GridLayout(11,1));
        this.setLocation(window_x,window_y);

        OrganismButtons = new JRadioButton[11];
        OrganismButtons[0] = new JRadioButton("Antelope");
        OrganismButtons[1] = new JRadioButton("Sheep");
        OrganismButtons[2] = new JRadioButton("CyberSheep");
        OrganismButtons[3] = new JRadioButton("Fox");
        OrganismButtons[4] = new JRadioButton("Turtle");
        OrganismButtons[5] = new JRadioButton("Wolf");
        OrganismButtons[6] = new JRadioButton("Belladonna");
        OrganismButtons[7] = new JRadioButton("Grass");
        OrganismButtons[8] = new JRadioButton("Guarana");
        OrganismButtons[9] = new JRadioButton("Hogweed");
        OrganismButtons[10] = new JRadioButton("Thistle");
        ButtonGroup organisms_group = new ButtonGroup();

        for(int i=0;i<11;i++){
            organisms_group.add(OrganismButtons[i]);
            OrganismButtons[i].addActionListener(this);
            this.add(OrganismButtons[i]);
        }

        this.pack();
        this.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if(e.getSource()==OrganismButtons[0]){
            world.place(new Antelope(world,-1,-1,-1,false),x,y);
            this.dispose();
        } else if (e.getSource()==OrganismButtons[1]) {
            world.place(new Sheep(world,-1,-1,-1,false),x,y);
            this.dispose();
        } else if (e.getSource()==OrganismButtons[2]) {
            world.place(new CyberSheep(world,-1,-1,-1,false),x,y);
            this.dispose();
        } else if (e.getSource()==OrganismButtons[3]) {
            world.place(new Fox(world,-1,-1,-1,false),x,y);
            this.dispose();
        } else if (e.getSource()==OrganismButtons[4]) {
            world.place(new Turtle(world,-1,-1,-1,false),x,y);
            this.dispose();
        } else if (e.getSource()==OrganismButtons[5]) {
            world.place(new Wolf(world,-1,-1,-1,false),x,y);
            this.dispose();
        } else if (e.getSource()==OrganismButtons[6]) {
            world.place(new Belladonna(world,-1,-1,-1,false),x,y);
            this.dispose();
        } else if (e.getSource()==OrganismButtons[7]) {
            world.place(new Grass(world,-1,-1,-1,false),x,y);
            this.dispose();
        } else if (e.getSource()==OrganismButtons[8]) {
            world.place(new Guarana(world,-1,-1,-1,false),x,y);
            this.dispose();
        } else if (e.getSource()==OrganismButtons[9]) {
            world.place(new Hogweed(world,-1,-1,-1,false),x,y);
            this.dispose();
        } else if (e.getSource()==OrganismButtons[10]) {
            world.place(new Thistle(world,-1,-1,-1,false),x,y);
            this.dispose();
        }
    }
}
