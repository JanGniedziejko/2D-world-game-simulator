import java.util.Objects;
import java.util.Random;


public abstract class Plant extends Organism{
    public Plant(World world, int strength, int x, int y, int age, boolean baby){
        super(world,strength,0,x,y,age,baby);
    }
    public void action(){
        if(!Objects.equals(this.getName(),"Thistle")){
            incrementAge();
        }
        Random rand = new Random();
        int sewing = rand.nextInt(20);
        if(sewing < 3){
            int[] newPosition = FindUnoccupiedField();
            if(newPosition[0] == -1 && newPosition[1] == -1){
                return;
            }
            else {
                reproduction(newPosition[0],newPosition[1]);
                getWorld().add("Sewing "+getName()+" at ("+getX()+","+getY()+")\n");
            }
        }
    }

    public boolean is_animal(){
        return false;
    }
}
