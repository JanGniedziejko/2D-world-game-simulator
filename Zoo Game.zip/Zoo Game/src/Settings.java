import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Settings {

    public Settings(){
        ImageIcon icon = new ImageIcon("Zoo.png");
        Image resizedImage = icon.getImage().getScaledInstance(103, 78, Image.SCALE_SMOOTH);
        ImageIcon resizedIcon = new ImageIcon(resizedImage);
        String[] responses= {"New Game", "Load Game"};
        int decision = JOptionPane.showOptionDialog(null,
                "Choose one of the options",
                "Zoo Game - Jan Gniedziejko 193633",
                JOptionPane.YES_NO_CANCEL_OPTION,
                JOptionPane.INFORMATION_MESSAGE,
                resizedIcon,responses, 0);

        System.out.print(decision);

        if (decision == 0){
            int[] board_wh = board_size();
            GUI_window window = new GUI_window(board_wh[0],board_wh[1]);
        }
        else if (decision == 1){
            GUI_window window = new GUI_window("data.txt");
        }
        // 0 = NEW GAME
        // 1 = LOAD GAME

    }

    public int[] board_size(){
        int[] sizes = new int[2];
        String width_str = JOptionPane.showInputDialog("Set the width of the board:");
        String height_str = JOptionPane.showInputDialog("Set the height of the board:");
        sizes[0] = decipher(width_str);
        sizes[1] = decipher(height_str);
        return sizes;
    }
    public int decipher(String line) {
        int num=0,powerOfTen=1;
        for(int i=line.length()-1;i>=0;i--){
            num += powerOfTen*(int)(line.charAt(i) - 48);
            powerOfTen *= 10;
        }
        return num;
    }
}
