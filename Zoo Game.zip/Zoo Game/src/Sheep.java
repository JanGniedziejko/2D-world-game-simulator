import java.awt.*;

public class Sheep extends Animal{
    public Sheep(World world, int x, int y, int age, boolean baby){
        super(world, 4, 4, x, y, age, baby);
    }

    public String draw(){
        return("S");
    }
    public String getName(){
        return ("Sheep");
    }

    public Organism reproduction(int x, int y){ return new Sheep(getWorld(), x, y, 1, true);
    };
}
