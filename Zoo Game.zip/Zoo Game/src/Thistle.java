import java.awt.*;

public class Thistle extends Plant {
    public Thistle(World world, int x, int y, int age, boolean baby){
        super(world,0,x,y,age,baby);
    }
    public String draw(){
        return("*");
    }
    public String getName(){
        return("Thistle");
    }
    public void action(){
        incrementAge();
        // 3 attempts to reproduce
        super.action();
        super.action();
        super.action();
    }
    public Organism reproduction(int x, int y){
        return new Thistle(getWorld(),x,y,1,true);
    }
}
