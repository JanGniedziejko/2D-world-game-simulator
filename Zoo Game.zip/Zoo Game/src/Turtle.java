import java.awt.*;
import java.util.Random;
public class Turtle extends Animal{

    public Turtle(World world, int x, int y, int age, boolean baby){
        super(world, 2, 1, x, y, age, baby);
    }

    public String draw(){
        return("T");
    };

    public String getName(){
        return ("Turtle");
    };

    @Override public void action(){
        incrementAge();
        // 25% likelihood to move
        Random rand = new Random();
        int move = rand.nextInt(4);
        if(move == 0){
            super.action();
        }
    };

    // Turtle's special ability
    @Override public boolean reflected(Organism organism){
        return(organism.getStrength() < 5);
    };

    public Organism reproduction(int x, int y){
        return new Turtle(getWorld(), x, y, 1, true);
    };
}
