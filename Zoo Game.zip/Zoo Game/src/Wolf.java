import java.awt.*;

public class Wolf extends Animal{
    public Wolf(World world, int x, int y, int age, boolean baby){
        super(world, 9, 5, x, y, age, baby);
    }
    public String draw(){
        return("W");
    };
    public String getName(){
        return ("Wolf");
    };

    public Organism reproduction(int x, int y){
        return new Wolf(getWorld(), x, y, 1, true);
    };
}
