import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.*;


public class World {
    private int w,h, move;
    private int turn = 1;
    private int Human_cld;
    private boolean end=false;
    private int humanStrength;
    private String text;
    private Organism[][] Organism_board;
    private Organism_Container All_organisms;
    private GUI_window board;
    protected JButton[][] Organism_button;

    public void setMove(int move){ this.move = move; }
    public int getMove(){ return move; }
    public void setJFrame(GUI_window board){
        this.board = board;
    }
    public JFrame getJFrame(){
        return board;
    }
    public void place(Organism organism, int x, int y){
        Random rand = new Random();
        int[] newPosition = new int[2];
        if(x == -1 && y == -1){
            newPosition[0] = rand.nextInt(w);
            newPosition[1] = rand.nextInt(h);
        }
        else{
            newPosition[0] = x;
            newPosition[1] = y;
        }
        if(organism.getAge() == -1){
            organism.setAge(rand.nextInt(20) + 2);
        }
        if (Organism_board[newPosition[0]][newPosition[1]] == null){
            organism.setX(newPosition[0]);
            organism.setY(newPosition[1]);
            Organism_board[newPosition[0]][newPosition[1]] = organism;
            Organism_button[newPosition[0]][newPosition[1]].setText(organism.draw());
            Organism_button[newPosition[0]][newPosition[1]].setEnabled(false);
            Organism_button[newPosition[0]][newPosition[1]].setBackground(null);
            All_organisms.add(organism);
        }
    }
    public World(int w, int h){
        this.w = w;
        this.h = h;

        Organism_button = new JButton[w][h];
        Organism_board = new Organism[w][h];
        for(int i=0;i<w;i++){
            for(int j=0;j<h;j++){
                Organism_board[i][j] = null;
                Organism_button[i][j] = new JButton("");
                Organism_button[i][j].setFont(new Font("Comic Sans", Font.BOLD | Font.PLAIN,25));
                final int x = i;
                final int y =j;
                Organism_button[i][j].addActionListener(e -> board.addOrganismToBoard(x,y));
            }
        }
        All_organisms = new Organism_Container(w*h);
        place(new Human(this,-1,-1,5,-1),-1,-1);
        place(new Sheep(this,-1,-1,-1,false),-1,-1);
        place(new Sheep(this,-1,-1,-1,false),-1,-1);
        place(new Wolf(this,-1,-1,-1,false),-1,-1);
        place(new Wolf(this,-1,-1,-1,false),-1,-1);
        place(new Grass(this,-1,-1,-1,false),-1,-1);
        place(new Thistle(this,-1,-1,-1,false),-1,-1);
        place(new Guarana(this,-1,-1,-1,false),-1,-1);
        place(new Guarana(this,-1,-1,-1,false),-1,-1);
        place(new Belladonna(this,-1,-1,-1,false),-1,-1);
        place(new Hogweed(this,-1,-1,-1,false),-1,-1);
        place(new Fox(this,-1,-1,-1,false),-1,-1);
        place(new Turtle(this,-1,-1,-1,false),-1,-1);
        place(new Turtle(this,-1,-1,-1,false),-1,-1);
        place(new Antelope(this,-1,-1,-1,false),-1,-1);
        place(new Antelope(this,-1,-1,-1,false),-1,-1);
        place(new CyberSheep(this,-1,-1,-1,false),-1,-1);
    }
    public World(String filename){
        try (Scanner scanner = new Scanner(new File(filename))) {
            String Specie;
            int x, y, age;
            boolean baby;
            w = scanner.nextInt();
            h = scanner.nextInt();
            turn = scanner.nextInt();
            humanStrength = scanner.nextInt();
            Human_cld = scanner.nextInt();

            Organism_button = new JButton[w][h];
            Organism_board = new Organism[w][h];
            for(int i=0;i<w;i++){
                for(int j=0;j<h;j++){
                    Organism_board[i][j] = null;
                    Organism_button[i][j] = new JButton("");
                    Organism_button[i][j].setFont(new Font("Comic Sans", Font.BOLD | Font.PLAIN,25));
                    final int button_x = i;
                    final int button_y = j;
                    Organism_button[i][j].addActionListener(e -> board.addOrganismToBoard(button_x,button_y));
                }
            }
            All_organisms = new Organism_Container(w*h);

            while (scanner.hasNext()){
                Specie = scanner.next();
                x = scanner.nextInt();
                y = scanner.nextInt();
                age = scanner.nextInt();
                baby = scanner.nextBoolean();
                if(Objects.equals(Specie,"Antelope")){
                    place(new Antelope(this, -1, -1, age, baby), x, y);
                }
                else if(Objects.equals(Specie,"Belladonna")){
                    place(new Belladonna(this, -1, -1, age, baby), x, y);
                }
                else if(Objects.equals(Specie,"Thistle")){
                    place(new Thistle(this, -1, -1, age, baby), x, y);
                }
                else if(Objects.equals(Specie,"Fox")){
                    place(new Fox(this, -1, -1, age, baby), x, y);
                }
                else if(Objects.equals(Specie,"Grass")){
                    place(new Grass(this, -1, -1, age, baby), x, y);
                }
                else if(Objects.equals(Specie,"Guarana")){
                    place(new Guarana(this, -1, -1, age, baby), x, y);
                }
                else if(Objects.equals(Specie,"Hogweed")){
                    place(new Hogweed(this, -1, -1, age, baby), x, y);
                }
                else if(Objects.equals(Specie,"Human")){
                    place(new Human(this, -1, -1,humanStrength, age,Human_cld), x, y);
                }
                else if(Objects.equals(Specie,"Sheep")){
                    place(new Sheep(this, -1, -1, age, baby), x, y);
                }
                else if(Objects.equals(Specie,"Turtle")){
                    place(new Turtle(this, -1, -1, age, baby), x, y);
                }
                else if(Objects.equals(Specie,"Wolf")){
                    place(new Wolf(this, -1, -1, age, baby), x, y);
                }
                else if (Objects.equals(Specie,"CyberSheep")) {
                    place(new CyberSheep(this, -1, -1, age, baby), x, y);
                }
            }

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public Organism getOrganismBoard(int horiz, int vert){
        return Organism_board[horiz][vert];
    }
    public void addOrganismToBoard(Organism organism,int x,int y){
        Organism_board[x][y] = organism;
        Organism_button[x][y].setText(organism.draw());
        Organism_button[x][y].setEnabled(false);
        Organism_button[x][y].setBackground(null);
    }
    public void removeOrganismFromBoard(int x, int y){
        Organism_board[x][y] = null;
        Organism_button[x][y].setText("");
        Organism_button[x][y].setEnabled(true);
    }
    public void changeCoordsOnBoard(int x, int y, Organism organism){
        Organism_board[x][y] = Organism_board[organism.getX()][organism.getY()];
        Organism_board[organism.getX()][organism.getY()] = null;
        Organism_button[x][y].setText(Organism_button[organism.getX()][organism.getY()].getText());
        Organism_button[x][y].setEnabled(false);
        Organism_button[organism.getX()][organism.getY()].setText("");
        Organism_button[organism.getX()][organism.getY()].setEnabled(true);
    }

    public void addToList(Organism organism){
        All_organisms.add(organism);
    }

    public void removeFromList(Organism organism){
        if(Objects.equals(organism.getName(),"Human")){
            end=true;
        }
        All_organisms.remove(organism);
    }
    //public World(int w, int h) saved world

    public int getWidth(){
        return w;
    }
    public int getHeight(){
        return h;
    }
    public int getHuman_cld(){
        return Human_cld;
    };
    public void setHuman_cld(int du) { Human_cld = du; }
    public void setStrength(int power){
        humanStrength = power;
    }
    public void add(String logs){
        text = text + logs + "\n";
    }
    public String getLogs(){
        return text;
    }

    public void makeTurn(){
        text="";
        Scanner scanner = new Scanner(System.in);
        OrganismNode current = All_organisms.getHead();
        if(Human_cld > 0) Human_cld--;
        while(current != null) {
            if (current.organism.getNewBorn()) {
                current.organism.noBaby();
            } else {
                current.organism.action();
            }
            current = current.next;
        }
        text = "\nTurn: "+turn+"\tStrength: "+humanStrength+"\n\n\n"+text;
        turn++;
    }
    public OrganismNode headOfOrganisms(){
        return All_organisms.getHead();
    }
    public void saveWorldState(){
        try (PrintWriter writer = new PrintWriter("data.txt")) {
            writer.println(w);
            writer.println(h);
            writer.println(turn);
            writer.println(humanStrength);
            writer.println(Human_cld);
            OrganismNode curr = All_organisms.getHead();
            while(curr != null){
                writer.println(curr.organism.getName());
                writer.println(curr.organism.getX());
                writer.println(curr.organism.getY());
                writer.println(curr.organism.getAge());
                writer.println(curr.organism.getNewBorn());
                curr = curr.next;
            }
            System.out.print("State of the game saved in file called: save.txt");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    public void EndGame(){
        if(end){
            board.disableButtons();
            JOptionPane.showMessageDialog(null,"End of the game","",JOptionPane.INFORMATION_MESSAGE);
        }
    }
}
